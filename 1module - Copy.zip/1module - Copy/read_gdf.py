import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np

def parse_gdf(file_path):
    """Parse the .gdf file and extract panel coordinates."""
    panels = []
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    # Skip header (assuming it's 2 lines in this case)
    lines = lines[4:]  
    
    # Read panels (4 vertices per panel)
    for i in range(0, len(lines), 4):
        try:
            # Each panel has 4 points (lines)
            panel = [list(map(float, line.split())) for line in lines[i:i+4]]
            panels.append(panel)
        except:
            break  # Stop if the remaining lines aren't complete panels
    return np.array(panels)

def plot_geometry(panels):
    """Visualize the panels in 3D."""
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')

    for panel in panels:
        # Create a polygon for each panel
        poly = Poly3DCollection([panel], alpha=0.5, edgecolor='k')
        ax.add_collection3d(poly)
    
    # Set the axes limits
    all_points = panels.reshape(-1, 3)
    # ax.set_xlim([np.min(all_points[:, 0]), np.max(all_points[:, 0])])
    ax.set_xlim([-1.5,1.5])
    ax.set_ylim([-1.5,1.5])
    ax.set_zlim([-1.5,1.1])    
    # ax.set_ylim([np.min(all_points[:, 1]), np.max(all_points[:, 1])])
    # ax.set_zlim([np.min(all_points[:, 2]), np.max(all_points[:, 2])])
    
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')
    # ax.set_title('3D Visualization of GDF Geometry')
    
    plt.show()

# Main execution
file_path = 'finemesh.gdf'  # Replace with your actual file path
panels = parse_gdf(file_path)
plot_geometry(panels)
