import numpy as np

def boxq_generator(length, width, draft, Nx, Ny, Nz):
    dx = 0.5 * length / Nx
    dy = 0.5 * width / Ny
    dz = draft / Nz

    Npanel = Nx * Ny + Nx * Nz + Ny * Nz
    X = np.zeros((Npanel, 4))
    Y = np.zeros((Npanel, 4))
    Z = np.zeros((Npanel, 4))

    x_vals = length/2 - np.arange(Nx+1) * dx
    y_vals = width/2 - np.arange(Ny+1) * dy
    z_vals = -np.arange(Nz+1) * dz

    i = 0

    for j in range(Nz):
        for p in range(Nx):
            X[i, :] = [x_vals[p+1], x_vals[p], x_vals[p], x_vals[p+1]]
            Y[i, :] = width / 2
            Z[i, :] = [z_vals[j], z_vals[j], z_vals[j+1], z_vals[j+1]]
            i += 1

    for j in range(Nz):
        for p in range(Ny):
            X[i, :] = length / 2
            Y[i, :] = [y_vals[p], y_vals[p] - dy, y_vals[p] - dy, y_vals[p]]
            Z[i, :] = [z_vals[j], z_vals[j], z_vals[j+1], z_vals[j+1]]
            i += 1

    for j in range(Nx):
        for p in range(Ny):
            X[i, :] = [x_vals[j], x_vals[j], x_vals[j+1], x_vals[j+1]]
            Y[i, :] = [y_vals[p], y_vals[p+1], y_vals[p+1], y_vals[p]]
            Z[i, :] = -draft
            i += 1

    return X, Y, Z, Npanel

def writetoGDF(X, Y, Z, Npanel, isx=0, isy=0, navn=""):
    filename = f"/mnt/data/BOX_{navn}.gdf"
    with open(filename, 'w') as fid1:
        fid1.write(f"BOX_{navn}.gdf  --\n")
        fid1.write("1.000       9.806650    ULEN, GRAV\n")
        fid1.write(f"{isx}           {isy}            ISX, ISY\n")
        fid1.write(f"{Npanel}    NPAN\n")

        for i in range(Npanel):
            for j in range(4):
                fid1.write(f"{X[i, j]:.6f} {Y[i, j]:.6f} {Z[i, j]:.6f} ")
                fid1.write("\n")
    return filename

# Example usage
length = 1.0
width = 1.3
draft = 0.15
Nx, Ny, Nz = 10, 26, 8
X, Y, Z, npanel = boxq_generator(length, width, draft, Nx, Ny, Nz)
filename = writetoGDF(X, Y, Z, npanel, 1, 1, "ExampleBox")

filename
