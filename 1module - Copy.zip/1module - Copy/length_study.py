import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

def box_generator(length, width, draft, Nx, Ny, Nz):
    dx = length / Nx
    dy = width / Ny
    dz = draft / Nz
    
    Npanel = Nx * Ny + Nx * Nz * 2 + Ny * Nz * 2
    X = np.zeros((Npanel, 4))
    Y = np.zeros((Npanel, 4))
    Z = np.zeros((Npanel, 4))
    
    i = 0
    
    for j in range(Nz):
        for p in range(Nx):
            Y[i, :] = -width / 2
            X[i, :] = [length/2 - (p)*dx, length/2 - (p+1)*dx, length/2 - (p+1)*dx, length/2 - (p)*dx]
            Z[i, :] = [-j*dz, -j*dz, -(j+1)*dz, -(j+1)*dz]
            i += 1
            
    for j in range(Nz):
        for p in range(Nx):
            Y[i, :] = width / 2
            X[i, :] = [length/2 - (p+1)*dx, length/2 - p*dx, length/2 - p*dx, length/2 - (p+1)*dx]
            Z[i, :] = [-j*dz, -j*dz, -(j+1)*dz, -(j+1)*dz]
            i += 1
            
    for j in range(Nz):
        for p in range(Ny):
            X[i, :] = length / 2
            Y[i, :] = [width/2 - p*dy, width/2 - (p+1)*dy, width/2 - (p+1)*dy, width/2 - p*dy]
            Z[i, :] = [-j*dz, -j*dz, -(j+1)*dz, -(j+1)*dz]
            i += 1
            
    for j in range(Nz):
        for p in range(Ny):
            X[i, :] = -length / 2
            Y[i, :] = [width/2 - (p+1)*dy, width/2 - p*dy, width/2 - p*dy, width/2 - (p+1)*dy]
            Z[i, :] = [-j*dz, -j*dz, -(j+1)*dz, -(j+1)*dz]
            i += 1
    
    for j in range(Nx):
        for p in range(Ny):
            
            Z[i, :] = -draft
            Y[i, :] = [width/2 - p*dy, width/2 - (p+1)*dy, width/2 - (p+1)*dy, width/2 - p*dy]
            X[i, :] = [length/2 - (j)*dx, length/2 - (j)*dx, length/2 - (j+1)*dx, length/2 - (j+1)*dx]
            i += 1
    
    return X, Y, Z, Npanel

import numpy as np


def boxq_generator(length, width, draft, Nx, Ny, Nz):
    dx = 0.5 * length / Nx
    dy = 0.5 * width / Ny
    dz = draft / Nz
    
    Npanel = Nx * Ny + Nx * Nz + Ny * Nz
    X = np.zeros((Npanel, 4))
    Y = np.zeros((Npanel, 4))
    Z = np.zeros((Npanel, 4))
    
    x_vals = length/2 - np.arange(Nx+1) * dx
    y_vals = width/2 - np.arange(Ny+1) * dy
    z_vals = -np.arange(Nz+1) * dz

    i = 0
    
    for j in range(Nz):
        for p in range(Nx):
            X[i, :] = [x_vals[p+1], x_vals[p], x_vals[p], x_vals[p+1]]
            Y[i, :] = width / 2
            Z[i, :] = [z_vals[j], z_vals[j], z_vals[j+1], z_vals[j+1]]
            i += 1
    
    for j in range(Nz):
        for p in range(Ny):
            X[i, :] = length / 2
            Y[i, :] = [y_vals[p], y_vals[p] - dy, y_vals[p] - dy, y_vals[p]]
            Z[i, :] = [z_vals[j], z_vals[j], z_vals[j+1], z_vals[j+1]]
            i += 1
    
    for j in range(Nx):
        for p in range(Ny):
            X[i, :] = [x_vals[j], x_vals[j], x_vals[j+1] , x_vals[j+1]]
            Y[i, :] = [y_vals[p], y_vals[p+1], y_vals[p+1], y_vals[p]]
            Z[i, :] = -draft
            i += 1
    
    return X, Y, Z, Npanel


def writetoGDF(X, Y, Z, Npanel, isx=0, isy=0, navn=""):
    """
    generates gdf for Wamit
    
    """
    if isx == 0 and isy == 0:
        print('No symetry plane')
    elif isx==1 and isy == 0:
        print('One symmtery plane x=0')
    elif isx==0 and isy == 1:
        print('One symmtery plane y=0')
    else:
        print('Symmtery planes x=y=0')
    
    
    
    # str1 = 'BOX.gdf'
    str1= f"BOX_{navn}.gdf"
    with open(str1, 'w') as file:
        file.write(f"{str1}  --\n")
        file.write("1.000       9.806650    ULEN, GRAV\n")
        file.write(f"{isx}           {isy}            ISX, ISY\n")
        file.write(f"{Npanel}    NPAN\n")
        
        for i in range(Npanel):
            for j in range(4):
                file.write(f"{X[i, j]:.6f} {Y[i, j]:.6f} {Z[i, j]:.6f} ")
                file.write("\n")
    with open(str1, 'w') as fid1:
        fid1.write(f"{str1}  --\n")
        fid1.write("1.000       9.806650    ULEN, GRAV\n")
        fid1.write(f"{isx}           {isy}            ISX, ISY\n")
        fid1.write(f"{Npanel}    NPAN\n")
        
        for i in range(Npanel):
            for j in range(4):
                fid1.write(f"{X[i, j]:.6f} {Y[i, j]:.6f} {Z[i, j]:.6f} ")
                fid1.write("\n")
            #fid1.write("\n")

def plotPanelNormals(X, Y, Z, Npanel):
    """
    Plotting normal vectors

  
    """
    
    xn = np.mean(X, axis=1)
    yn = np.mean(Y, axis=1)
    zn = np.mean(Z, axis=1)
    
    u = np.zeros(Npanel)
    v = np.zeros(Npanel)
    w = np.zeros(Npanel)
    
    for i in range(Npanel):
        v1 = np.array([X[i, 2] - X[i, 0], Y[i, 2] - Y[i, 0], Z[i, 2] - Z[i, 0]])
        v2 = np.array([X[i, 3] - X[i, 1], Y[i, 3] - Y[i, 1], Z[i, 3] - Z[i, 1]])
        n = np.cross(v1, v2)
        n_hat = n / np.linalg.norm(n)
        u[i], v[i], w[i] = n_hat
        
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.quiver(xn, yn, zn, u, v, w)

def plot_3D_panel(X, Y, Z, npanel):
    """
    Create a 3D plot of panels.

    Parameters:
    - X, Y, Z: Arrays containing coordinates for the panels.
    - npanel: Number of panels.
    """
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    # Loop through each panel
    for i in range(npanel):
        ax.plot(X[i, :], Y[i, :], Z[i, :], label=f'{i+1}th ')
        ax.text(np.mean(X[i, :]), np.mean(Y[i, :]), np.mean(Z[i, :]), f'{i}th', fontsize=9)

    # Label axes
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    ax.set_zlabel('z')

    ax.set_aspect('equal', 'box')

    # View angle
    ax.view_init(azim=3)  

    
    # plotPanelNormals(X, Y, Z, npanel)

    plt.show()

if __name__ == "__main__":
    aspect_ratio = 8.6667 # ASpect ratio fra utdelt kode
    widths={
        "Gunnar": 10
    }
    for name, width in widths.items():
        #dimx = [10, 20, 30, 40, 50, 80, 100, 110, 120, 140, 150] #VOL 2
        # dimx = [10, 30, 50, 80, 100, 120, 140, 150] #VOL 3
        dimx = [1]
        for i,el in enumerate(dimx):
            draft = width / aspect_ratio
            dimx2 = 5
            #dimx2 = 20
            length = 2
            X, Y, Z, npanel = boxq_generator(length, 1.3, 0.15, int(length*dimx2), 3, 3)
            #X, Y, Z, npanel = boxq_generator(length, 1.3, 0.15, int(length*dimx2), 20, 10)
            #temp_name=name+"_"+str(i)
            temp_name=name+"_"+str(length)
            writetoGDF(X, Y, Z, npanel, 1, 1, temp_name )
            print("Wrote GDF file for", name, "with length", length)
        # plotPanelNormals(X, Y, Z, npanel)
        # plot_3D_panel(X, Y, Z, npanel)
    # dimy=6   #Bredde fra utdelt kode

    # dimx=10
    # draft=dimy/aspect_ratio   
  
    # X, Y, Z, npanel = box_generator(dimx, dimy, draft, 10, 5, 3)   ##generates a complete box in 3D
    # writetoGDF(X, Y, Z, npanel,1,1)  

    ##X, Y, Z, npanel = boxq_generator(dimx, dimy, draft, 4, 4, 3)   ##generates a quarter of a box in 3D 

    #Commented out for mass production of boxes
    # plotPanelNormals(X, Y, Z, npanel)
    # plot_3D_panel(X, Y, Z, npanel)
    
    

