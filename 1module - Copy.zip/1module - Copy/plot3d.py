import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib import cm
import numpy as np
from matplotlib import rcParams


# Use Computer Modern font
rcParams.update({
    "font.family": "serif",
    "font.serif": ["CMU Serif", "Computer Modern Roman", "DejaVu Serif"],
    "mathtext.fontset": "cm",
})

def parse_gdf(file_path):
    """Parse the .gdf file and extract panel coordinates."""
    panels = []
    with open(file_path, 'r') as f:
        lines = f.readlines()
    
    # Skip header (assuming it's 2 lines in this case)
    lines = lines[4:]  
    
    # Read panels (4 vertices per panel)
    for i in range(0, len(lines), 4):
        try:
            # Each panel has 4 points (lines)
            panel = [list(map(float, line.split())) for line in lines[i:i+4]]
            panels.append(panel)
        except:
            break  # Stop if the remaining lines aren't complete panels
    return np.array(panels)

def plot_geometry_bw(panels, save_path=None):
    """Visualize the panels in 3D with a black-and-white aesthetic and a white-filled grid."""
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d', azim=45, elev=30)  # Set a good viewing angle

    # Use a grayscale colormap for simplicity
    cmap = cm.gray
    for i, panel in enumerate(panels):
        color = cmap(0.5 + 0.5 * i / len(panels))  # Gradually change grayscale intensity
        poly = Poly3DCollection([panel], alpha=0.8, facecolor=color, edgecolor='k', linewidths=0.5)
        ax.add_collection3d(poly)
    
    # Set the axes limits
    ax.set_xlim([-0.5, 1.5])
    ax.set_ylim([-0.5, 1.5])
    ax.set_zlim([-1,1])
    
    # Customize the axes labels
    ax.set_xlabel(r'$x$ [m]', fontsize=15, labelpad=5)
    ax.set_ylabel(r'$y$ [m]', fontsize=15, labelpad=5)
    ax.set_zlabel(r'$z$ [m]', fontsize=15, labelpad=5)


    # Adjust the Z-axis label to fix its orientation
   # Turn off the default Z label
    ax.set_zlabel('')

# Add a custom Z label with math mode, placed manually
    ax.text(2.05, -0.5, 0.21, r'$z$ [m]', fontsize=15, rotation=0)
     

    # ax.zaxis.label.set_rotation(9)  # Ensure the Z label stays upright
    # ax.zaxis.label.set_verticalalignment('bottom')  # Adjust vertical alignment if needed

    ax.tick_params(axis='both', which='major', labelsize=10)
    
    # Add white background to the grid
    ax.xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))  # XZ plane (white)
    ax.yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))  # YZ plane (white)
    ax.zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))  # XY plane (white)
    
    # Set grid lines to black
    ax.grid(True, linestyle='--', color='k', alpha=0.6)
    
    # Tighten layout
    plt.tight_layout()
    
    # Save as PDF if a path is specified
    if save_path:
        plt.savefig(save_path, format='pdf')
    
    plt.show()

# Main execution
file_path = 'mesh3.gdf'  # Replace with your actual file path
panels = parse_gdf(file_path)

# Save as PDF
plot_geometry_bw(panels, save_path="geometry_visualization_bw.pdf")
